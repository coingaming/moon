(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[12],{

/***/ 23:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

}]);