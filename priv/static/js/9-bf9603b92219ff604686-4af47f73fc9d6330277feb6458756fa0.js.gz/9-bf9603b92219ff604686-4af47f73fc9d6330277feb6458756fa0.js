(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[9],{

/***/ "./js/components/avatar.js":
/*!*********************************!*\
  !*** ./js/components/avatar.js ***!
  \*********************************/
/*! no exports provided */
/*! ModuleConcatenation bailout: Module is an entry point */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var moon_css_example_components_avatar_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moon-css/example/components/avatar.scss */ \"./node_modules/moon-css/example/components/avatar.scss\");\n/* harmony import */ var moon_css_example_components_avatar_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moon_css_example_components_avatar_scss__WEBPACK_IMPORTED_MODULE_0__);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qcy9jb21wb25lbnRzL2F2YXRhci5qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL2pzL2NvbXBvbmVudHMvYXZhdGFyLmpzPzU1ZjAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwibW9vbi1jc3MvZXhhbXBsZS9jb21wb25lbnRzL2F2YXRhci5zY3NzXCIiXSwibWFwcGluZ3MiOiJBQUFBO0FBQUE7QUFBQTsiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./js/components/avatar.js\n");

/***/ })

},[["./js/components/avatar.js",0,27]]]);