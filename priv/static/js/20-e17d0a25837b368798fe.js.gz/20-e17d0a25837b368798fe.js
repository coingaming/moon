(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[20],{

/***/ "./js/components/text.js":
/*!*******************************!*\
  !*** ./js/components/text.js ***!
  \*******************************/
/*! no exports provided */
/*! ModuleConcatenation bailout: Module is an entry point */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n!(function webpackMissingModule() { var e = new Error(\"Cannot find module 'moon-css/example/components/text.scss'\"); e.code = 'MODULE_NOT_FOUND'; throw e; }());\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9qcy9jb21wb25lbnRzL3RleHQuanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9qcy9jb21wb25lbnRzL3RleHQuanM/OTM0YyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCJtb29uLWNzcy9leGFtcGxlL2NvbXBvbmVudHMvdGV4dC5zY3NzXCIiXSwibWFwcGluZ3MiOiJBQUFBO0FBQUE7Iiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./js/components/text.js\n");

/***/ })

},[["./js/components/text.js",0]]]);