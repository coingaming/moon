(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[73],{

/***/ 77:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var moon_css_example_components_avatar_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(78);
/* harmony import */ var moon_css_example_components_avatar_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moon_css_example_components_avatar_scss__WEBPACK_IMPORTED_MODULE_0__);


/***/ })

},[[77,0,38]]]);